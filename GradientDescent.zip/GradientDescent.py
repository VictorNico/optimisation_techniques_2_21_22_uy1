import sympy as sp

def f(x, y):
    return ((x**2)/2)+(7*(y**2)/2)

def gradient(function, argsf):
    Lf = []
    for var in argsf:
        Lf.append(function.diff(var))
    return sp.Matrix(Lf)

def normalize(vector):
    vector = sp.Matrix(vector)
    norm = 0
    for x in vector:
        norm += x**2
    return sp.sqrt(norm)

def fixedDepht(function, argsf, s, point, e = 10**(-5), nbr=100):
    Lf = gradient(function) #calcul du gradient de la fonction
    X = sp.Matrix(point) #X[0] est le point de depart
    
    k = 0
    while (k < nbr):
        precedent = [] #X[k]
        for i in range(len(argsf)):
            precedent.append((argsf[i], X[i])) #creer une liste de substitution avec X[k]
        
        grad = [] #Lf(X[k])
        for expr in Lf:
            grad.append(expr.subs(precedent)) #calcul des coordonees de Lf(X[k])
        grad = sp.Matrix(grad)
        
        if ((normalize(grad)) < e): #arreter si ||lf(X[k])|| < precision
            break
            
        X = sp.Matrix(X - s*grad) #calcul de X[k+1] = X[k]-s*Lf(X[k])
        k += 1
        
    return X #retour du dernier X[k]

def s(x, y):
    return (x**2 + ((7**2)*(y**2))) / (x**2 + ((7**3)*(y**2)))

def optimalDepht(function, argsf, dephtFunction, point, e = 10**(-5), nbr=100):
    Lf = gradient(function) #calcul du gradient de la fonction
    X = sp.Matrix(point) #X[0] est le point de depart
    
    k = 0
    while (k < nbr):
        precedent = [] #X[k]
        for i in range(len(argsf)):
            precedent.append((argsf[i], X[i])) #creer une liste de substitution avec X[k]
        
        grad = [] #Lf(X[k])
        for expr in Lf:
            grad.append(expr.subs(precedent)) #calcul des coordonees de Lf(X[k])
        grad = sp.Matrix(grad)
        
        if ((normalize(grad)) < e): #arreter si ||lf(X[k])|| < precision
            break
        
        s = dephtFunction.subs(precedent) #calcul du pas S[k] en fonction X[k]
        X = sp.Matrix(X - s*grad) #calcul de X[k+1] = X[k]-S[k]*Lf(X[k])
        k += 1
        
    return X #retour du dernier X[k]

def hessian(function, argsf):
    H = []
    for i in argsf:
        line = []
        for j in argsf:
            line.append(function.diff(j).diff(i))
        H.append(line)
    return sp.Matrix(H)

def newtonDirection(function, argsf):
    Hf = hessian(function) #calcul de la hessiene de la fonction
    Lf = gradient(function) #calcul du gradient de la fonction
    
    U = [] #variables pour le systeme lineaire Hf*U = -Lf
    for i in range(len(argsf)):
        U.append(sp.symbols("u"+str(i))) #creation des variables
    U = sp.Matrix(U)
    
    solution = sp.solve(Hf*U + Lf, U) #calcul des solution du system lineaire Hf*U = -Lf 
    
    D = [] #vecteur de la direction de newton
    for u in U:
        D.append(solution[u]) #passer les valeurs de la solution au vecteur de newton
    D = sp.Matrix(D)

    return D #retour du vecteur de newton

def localNewton(function, argsf, point, e = 10**(-5), nbr=100):
    Lf = gradient(function) #calcul du gradient de la fonction
    DNf = newtonDirection(function) #calcul de la direction de newton de la fonction
    X = sp.Matrix(point) #X[0] est le point de depart
    
    k = 0
    while (k < nbr):
        precedent = [] #X[k]
        for i in range(len(argsf)):
            precedent.append((argsf[i], X[i])) #creer une liste de substitution avec X[k]
        
        grad = [] #Lf(X[k])
        for expr in Lf:
            grad.append(expr.subs(precedent)) #calcul des coordonees de Lf(X[k])
        grad = sp.Matrix(grad)
        
        if ((normalize(grad)) < e): #arreter si ||lf(X[k])|| < precision
            break
            
        d = [] #DNf(X[k])
        for expr in DNf:
            d.append(expr.subs(precedent)) #calcul des coordonees de DNf(X[k])
        d = sp.Matrix(d)

        X = sp.Matrix(X + d) #calcul de X[k+1] = X[k]+D[k]
        k += 1
        
    return X #retour du dernier X[k]

"""A executer une a une les lignes suivantes
#x, y = sp.symbols('x, y')

#fixedDepht(f(x,y), (x,y), 0.2, [7, 1.5], 10**(-5))

#optimalDepht(f(x,y), (x,y), s(x,y), [7, 1.5], 10**(-5))

#localNewton(f(x,y), (x,y), [7, 1.5], 10**(-5))
"""
